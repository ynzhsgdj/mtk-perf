# !/sbin/sh

# @nohavenames    telegram 

busybox mount /system


if [ ! -f /system/vendor/etc/thermal.conf.parth ]; then
  cp /system/vendor/etc/thermal.conf /system/vendor/etc/thermal.conf.parth
fi

if [ ! -f /system/etc/thermal.conf.parth ]; then
  cp /system/etc/thermal.conf /system/vendor/etc/thermal.conf.parth
fi

if [ ! -f /system/vendor/etc/.tp/thermal.conf.parth ]; then
  cp /system/vendor/etc/.tp/thermal.conf /system/vendor/etc/thermal.conf.parth
fi

if [ ! -f /system/etc/thermal.conf.parth ]; then
  cp /system/etc/thermal.conf /system/vendor/etc/.tp/thermal.conf.parth
fi




if [ ! -f /system/vendor/etc/mi_thermald.conf.parth ]; then
  cp /system/vendor/etc/thermal.conf /system/vendor/etc/thermal.conf.parth
fi

if [ ! -f /system/etc/mi_thermald.conf.parth ]; then
  cp /system/etc/thermal.conf /system/vendor/etc/thermal.conf.parth
fi

if [ ! -f /system/vendor/etc/.tp/mi_thermald.conf.parth ]; then
  cp /system/vendor/etc/.tp/mi_thermald.conf.parth /system/vendor/etc/mi_thermald.conf.parth
fi

if [ ! -f /system/etc/mi_thermald.conf.parth ]; then
  cp /system/etc/mi_thermald.conf.parth /system/vendor/etc/.tp/mi_thermald.conf.parth
fi